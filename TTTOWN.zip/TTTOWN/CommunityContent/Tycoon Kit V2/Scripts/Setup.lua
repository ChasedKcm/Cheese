--Declares _G.owners as an empty table
_G.owners = {}