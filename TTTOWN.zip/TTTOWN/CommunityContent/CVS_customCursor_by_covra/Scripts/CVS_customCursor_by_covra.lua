--[[ 

CVS_customCursor_by_covra
=========================

ES

	Sencillo script para customizar el cursor en nuestros juegos. 
	Arrastralo directamente sobre la jerarquia del proyecto
	La plantilla viene con tres ejemplos cutres:
		- 0 = default: el que se cargara al inicio
		- 1 = ArtCursor_2
		- 2 = ArtCursor_3
	El propio 'arte' del cursor esta dentro de esos paneles (que son los que realmente se mueven)
	
	Importante:
	----------
		* Para activar (ver) el cursor se puede usar broadcasting, ejemplos:
			- Activacion del cursor de un script en el lado del cliente:
		
					Events.Broadcast("setCustomCursorVisibility", true, 0)
					
			- Para un determinado jugador	(desde el servidor):		
	
					Events.BrodcastToPlayer(player, "setCustomCursorVisibility", true , 2)
					
			- Para desactivarlo (Quitar visibilidad del cursor desde el cliente):			
		
					Events.Broadcast("setCustomCursorVisibility", false)
				
	Disfrutenlo ;)
				
-------------------------------------------------------------------------------------------------------------

EN 

	Simple script to customize the cursor in our games.
	Drag and Drop into hierarchy
	The template comes with three crappy examples:
		- 0 = default: the one that will be loaded at the beginning
		- 1 = ArtCursor_2
		- 2 = ArtCursor_3
	The cursor's own 'art' is within those panels (which are the ones that actually move)

	Important:
	----------
		* To activate (see) the cursor you can use broadcasting, examples:
			- Activate cursor from client script:
			
					Events.Broadcast("setCustomCursorVisibility", true, 2)
	
			- For a specific player (from the server):
				
					Events.BrodcastToPlayer(player, "setCustomCursorVisibility", true , 2)
			
			- To deactivate it (Remove cursor visibility from the client):
			
					Events.Broadcast("setCustomCursorVisibility", false)
			
	Enjoy it;)		

    ...by CoVrA  2020, contenido en espaÑol ;)  
    
 
 covrita's Indie Game Server
 ---------------------------
 https://discord.gg/JKXN4rQNAs
    
 CORE user: 
 ----------
 https://www.coregames.com/user/2806d3a81a1945d98531567cd86090ac  
 
 CoVraworkS
 -----------
 https://www.youtube.com/channel/UCC_eVHHtZB1LD-_x4KT6Lug

]]--

--custom
local parentClient = script.parent
local cursorDefault = script:GetCustomProperty("UIcursorDefault"):WaitForObject()
local ArtCursor_2 = script:GetCustomProperty("UIArtCursor_2"):WaitForObject()
local ArtCursor_3 = script:GetCustomProperty("UIArtCursor_3"):WaitForObject()
--local
local cursorActive = cursorDefault
local isActiveCustomCursor = true


function Tick ()
	if not isActiveCustomCursor then return end
 		local cursorPos = UI.GetCursorPosition()
		cursorActive.x = cursorPos.x
		cursorActive.y = cursorPos.y
end

--f. Desactiva la visibilidad de los cursores
function switchOffCursor()
	cursorDefault.visibility = Visibility.FORCE_OFF
	ArtCursor_2.visibility = Visibility.FORCE_OFF
	ArtCursor_3.visibility = Visibility.FORCE_OFF

end

--f. determina que cursor esta activo
function setCursorActive (cursorIn)
	switchOffCursor()
	cursorActive = cursorIn
	cursorActive.visibility = Visibility.FORCE_ON
	print(script.name.." >> custom cursor active now is; ", cursorActive.name)
end

--f. EVENT recibe la informacion del broadcasting
function setCustomCursor (boolIn,optionIn)
	if boolIn then
		if optionIn == 0 then setCursorActive(cursorDefault)
		elseif optionIn == 1 then setCursorActive (ArtCursor_2)
		elseif optionIn == 2 then setCursorActive (ArtCursor_3)
		end
	elseif not boolIn then
		switchOffCursor ()
		print(script.name.." >> custom cursor is not visible now ")
	end
end

--f. Secuencia de auto inicio
function init()
	UI.SetCursorVisible(false)
	UI.SetCursorLockedToViewport(true)
	setCursorActive(cursorDefault)
	Events.Connect("setCustomCursorVisibility", setCustomCursor)
end

--Inicio>>
init()